package com.mn.club.repositories;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.mn.club.models.PatronModel;

import jakarta.persistence.EntityManager;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;


@Repository
public interface PatronRepository extends JpaRepository<PatronModel, Long> {
	
	default List<PatronModel> findPatronesByApellido(String apellido) {
        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<PatronModel> criteriaQuery = criteriaBuilder.createQuery(PatronModel.class);
        Root<PatronModel> root = criteriaQuery.from(PatronModel.class);

        Predicate predicate = criteriaBuilder.equal(root.get("apellido"), apellido);
        criteriaQuery.where(predicate);

        return entityManager.createQuery(criteriaQuery).getResultList();
    }

    EntityManager getEntityManager();
    
    //aquí usamos la interfaz EntityManager para obtener una instancia de EntityManager que nos permite construir y ejecutar la consulta Criteria.
    //creamos un CriteriaQuery para especificar el tipo de resultados que esperamos obtener (en este caso, objetos PatronModel).
    //creamos un Root que representa la entidad raíz de la consulta (en este caso, PatronModel).
    //filtramos los resultados por el apellido del patrón con el Predicate
    //y ejecutamos la consulta para devolver resultados

} 
